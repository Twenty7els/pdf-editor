"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { usePdfEditorStore, StampItem, TextItem, EraserPoint, getFontCss, AVAILABLE_FONTS } from "@/store/pdf-editor-store";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Maximize,
  RotateCcw,
  RotateCw,
  Trash2,
  Bold,
  Italic,
  Eraser,
} from "lucide-react";
import { Input } from "@/components/ui/input";

type DragMode = "move" | "resize" | "rotate" | null;

interface DragState {
  mode: DragMode;
  id: string;
  type: "stamp" | "text";
  // for move
  offsetX: number;
  offsetY: number;
  // for resize — which corner: tl, tr, bl, br
  corner?: string;
  startX: number;
  startY: number;
  startLeft: number;
  startTop: number;
  startWidth: number;
  startHeight: number;
  // for rotate
  startRotation: number;
  startAngle: number;
  // stored canvas dims for coordinate conversion
  itemCanvasWidth: number;
  itemCanvasHeight: number;
}

const HANDLE_SIZE = 8;
const ROTATE_HANDLE_DISTANCE = 25;

export default function PdfCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const [pdfDoc, setPdfDoc] = useState<unknown | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [pdfjsReady, setPdfjsReady] = useState(false);
  const pdfjsRef = useRef<unknown>(null);
  const renderingRef = useRef(false);
  const baseScaleRef = useRef(1.0);
  const clickedOnElementRef = useRef(false);

  // Eraser drawing state
  const [isEraserDrawing, setIsEraserDrawing] = useState(false);
  const [currentEraserPoints, setCurrentEraserPoints] = useState<EraserPoint[]>([]);
  const [eraserCursorPos, setEraserCursorPos] = useState<{ x: number; y: number } | null>(null);

  // Stamp cursor state
  const [stampCursorPos, setStampCursorPos] = useState<{ x: number; y: number } | null>(null);

  const {
    pdfFile,
    currentPage,
    totalPages,
    zoomLevel,
    setTotalPages,
    setPdfArrayBuffer,
    setPageScale,
    zoomIn,
    zoomOut,
    zoomFit,
    activeTool,
    selectedStampType,
    selectedStampSrc,
    stamps,
    texts,
    erasers,
    selectedItemId,
    selectedItemType,
    addStamp,
    addText,
    addEraser,
    updateStamp,
    updateText,
    updateEraser,
    setSelectedItem,
    setCurrentPage,
    setActiveTool,
    textSettings,
    setTextSettings,
    eraserSettings,
    setEraserSettings,
    presetText,
    setPresetText,
  } = usePdfEditorStore();

  // Scale stored overlay coordinates → current display coordinates
  // Must be declared BEFORE handlers that use them
  const scaleToDisplay = useCallback((storedX: number, storedCanvasWidth: number) => {
    if (!canvasSize.width || !storedCanvasWidth) return storedX;
    return storedX * (canvasSize.width / storedCanvasWidth);
  }, [canvasSize.width]);

  const scaleToDisplayY = useCallback((storedY: number, storedCanvasHeight: number) => {
    if (!canvasSize.height || !storedCanvasHeight) return storedY;
    return storedY * (canvasSize.height / storedCanvasHeight);
  }, [canvasSize.height]);

  const scaleToStore = useCallback((displayX: number, storedCanvasWidth: number) => {
    if (!canvasSize.width || !storedCanvasWidth) return displayX;
    return displayX * (storedCanvasWidth / canvasSize.width);
  }, [canvasSize.width]);

  const scaleToStoreY = useCallback((displayY: number, storedCanvasHeight: number) => {
    if (!canvasSize.height || !storedCanvasHeight) return displayY;
    return displayY * (storedCanvasHeight / canvasSize.height);
  }, [canvasSize.height]);

  // Drag / resize / rotate state
  const [dragState, setDragState] = useState<DragState | null>(null);

  // Text editing
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  const [editTextValue, setEditTextValue] = useState("");

  // Load pdfjs-dist dynamically on mount
  useEffect(() => {
    let cancelled = false;
    const loadPdfjs = async () => {
      try {
        const pdfjs = await import("pdfjs-dist");
        if (cancelled) return;
        pdfjs.GlobalWorkerOptions.workerSrc = "/pdf-worker/pdf.worker.min.mjs";
        pdfjsRef.current = pdfjs;
        setPdfjsReady(true);
      } catch (err) {
        console.error("Failed to load pdfjs-dist:", err);
        setError("Ошибка загрузки PDF.js библиотеки");
      }
    };
    loadPdfjs();
    return () => { cancelled = true; };
  }, []);

  // Load PDF when file changes
  useEffect(() => {
    if (!pdfFile || !pdfjsRef.current) return;
    const loadPdf = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const arrayBuffer = await pdfFile.arrayBuffer();
        setPdfArrayBuffer(arrayBuffer.slice(0));
        const pdfjs = pdfjsRef.current as typeof import("pdfjs-dist");
        const pdf = await pdfjs.getDocument({
          data: new Uint8Array(arrayBuffer),
          useSystemFonts: true,
        }).promise;
        setPdfDoc(pdf);
        setTotalPages(pdf.numPages);

        // Check page sizes against A4 standard
        const A4_WIDTH = 595.28;  // 210mm in points
        const A4_HEIGHT = 841.89; // 297mm in points
        const TOLERANCE = 5; // ~1.76mm tolerance for rounding differences

        const nonA4Pages: number[] = [];
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const vp = page.getViewport({ scale: 1 });
          const w = vp.width;
          const h = vp.height;

          const isPortraitA4 = Math.abs(w - A4_WIDTH) <= TOLERANCE && Math.abs(h - A4_HEIGHT) <= TOLERANCE;
          const isLandscapeA4 = Math.abs(w - A4_HEIGHT) <= TOLERANCE && Math.abs(h - A4_WIDTH) <= TOLERANCE;

          if (!isPortraitA4 && !isLandscapeA4) {
            nonA4Pages.push(i);
          }
        }

        if (nonA4Pages.length > 0) {
          const pageList = nonA4Pages.length <= 5
            ? nonA4Pages.join(", ")
            : nonA4Pages.slice(0, 5).join(", ") + "...";
          toast.warning(`Формат страниц не А4: стр. ${pageList}. Размер может отличаться от стандартного.`, {
            duration: 6000,
          });
        }
      } catch (err) {
        console.error("Error loading PDF:", err);
        setError("Ошибка загрузки PDF файла");
      } finally {
        setIsLoading(false);
      }
    };
    loadPdf();
  }, [pdfFile, pdfjsReady, setTotalPages, setPdfArrayBuffer]);

  // Render current page with zoom
  const renderPage = useCallback(async () => {
    if (!pdfDoc || !canvasRef.current || renderingRef.current) return;
    renderingRef.current = true;
    try {
      const pdf = pdfDoc as import("pdfjs-dist").PDFDocumentProxy;
      const page = await pdf.getPage(currentPage);
      const container = containerRef.current;
      if (!container) { renderingRef.current = false; return; }
      const containerWidth = container.clientWidth - 40;
      // Skip render if container hasn't been laid out yet
      if (containerWidth < 100) { renderingRef.current = false; return; }
      const viewport = page.getViewport({ scale: 1 });
      const fitScale = containerWidth / viewport.width;
      baseScaleRef.current = fitScale;
      const scale = fitScale * zoomLevel;
      setPageScale(scale);
      const scaledViewport = page.getViewport({ scale });
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");
      if (!context) { renderingRef.current = false; return; }
      const outputScale = window.devicePixelRatio || 1;
      canvas.width = Math.floor(scaledViewport.width * outputScale);
      canvas.height = Math.floor(scaledViewport.height * outputScale);
      canvas.style.width = Math.floor(scaledViewport.width) + "px";
      canvas.style.height = Math.floor(scaledViewport.height) + "px";
      const transform = outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : undefined;
      setCanvasSize({ width: Math.floor(scaledViewport.width), height: Math.floor(scaledViewport.height) });
      await page.render({ canvasContext: context, viewport: scaledViewport, transform }).promise;
    } catch (err) {
      console.error("Error rendering page:", err);
    } finally {
      renderingRef.current = false;
    }
  }, [pdfDoc, currentPage, zoomLevel, setPageScale]);

  // Initial render + delayed re-render to catch layout changes (sidebar appearing etc)
  useEffect(() => {
    if (!pdfDoc) return;
    renderPage();
    // Re-render after layout settles (sidebar, viewport changes)
    const t1 = setTimeout(() => renderPage(), 100);
    const t2 = setTimeout(() => renderPage(), 400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [renderPage, pdfDoc]);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    const handleResize = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => { if (pdfDoc) renderPage(); }, 200);
    };
    window.addEventListener("resize", handleResize);
    return () => { window.removeEventListener("resize", handleResize); clearTimeout(timeout); };
  }, [pdfDoc, renderPage]);

  // Scale stamps/texts when canvas size changes (due to zoom)
  // REMOVED: we now compute display positions on the fly via scaleToDisplay()
  // This eliminates drift from repeated mutation of stored coordinates

  // Clear cursors when switching tools
  useEffect(() => {
    if (activeTool !== "eraser") setEraserCursorPos(null);
    if (activeTool !== "stamp") setStampCursorPos(null);
  }, [activeTool]);

  // Mouse wheel zoom with Ctrl
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const handleWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        if (e.deltaY < 0) zoomIn(); else zoomOut();
      }
    };
    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => container.removeEventListener("wheel", handleWheel);
  }, [zoomIn, zoomOut]);

  // Handle click on canvas overlay
  const handleOverlayClick = useCallback(
    (e: React.MouseEvent) => {
      if (!overlayRef.current) return;
      if (e.target !== overlayRef.current) return;
      // Skip if user just clicked on an existing element (stamp/text/handle)
      if (clickedOnElementRef.current) {
        clickedOnElementRef.current = false;
        return;
      }
      const rect = overlayRef.current.getBoundingClientRect();
      const overlayW = overlayRef.current.offsetWidth;
      const overlayH = overlayRef.current.offsetHeight;

      if (activeTool === "stamp" && selectedStampType && selectedStampSrc) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const size = 130;
        const newId = `stamp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        addStamp({
          id: newId,
          type: selectedStampType,
          src: selectedStampSrc,
          x: x - size / 2,
          y: y - size / 2,
          width: size,
          height: size,
          page: currentPage,
          rotation: 0,
          opacity: 1.0,
          canvasWidth: overlayW,
          canvasHeight: overlayH,
        });
        // Auto-switch to select mode after placing stamp
        setActiveTool("select");
        setSelectedItem(newId, "stamp");
      } else if (activeTool === "text") {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const textContent = presetText || "Текст";
        const newText: TextItem = {
          id: `text-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          text: textContent,
          x, y,
          fontSize: textSettings.fontSize,
          color: textSettings.color,
          page: currentPage,
          fontFamily: textSettings.fontFamily,
          bold: textSettings.bold,
          italic: textSettings.italic,
          rotation: 0,
          canvasWidth: overlayW,
          canvasHeight: overlayH,
        };
        addText(newText);
        setSelectedItem(newText.id, "text");
        // Only open editing for non-preset text (let user type their own)
        if (!presetText) {
          setEditingTextId(newText.id);
          setEditTextValue(textContent);
        }
        // Auto-switch to select mode after placing text
        setActiveTool("select");
        setPresetText(null);
      } else if (activeTool === "select") {
        setSelectedItem(null, null);
        setEditingTextId(null);
      }
      // Note: eraser handles its own mousedown in handleOverlayMouseDown
    },
    [activeTool, selectedStampType, selectedStampSrc, currentPage, textSettings, presetText, addStamp, addText, setSelectedItem, setActiveTool, setPresetText]
  );

  // Handle overlay mousedown for eraser brush drawing
  const handleOverlayMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (activeTool !== "eraser") return;
      if (!overlayRef.current) return;
      // Only start drawing when clicking directly on the overlay
      const target = e.target as HTMLElement;
      if (target !== overlayRef.current) return;

      const rect = overlayRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      setIsEraserDrawing(true);
      setCurrentEraserPoints([{ x, y }]);
    },
    [activeTool]
  );

  // Handle eraser drawing mouse move and mouseup (window-level)
  useEffect(() => {
    if (!isEraserDrawing || !overlayRef.current) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = overlayRef.current!.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      setCurrentEraserPoints(prev => [...prev, { x, y }]);
      setEraserCursorPos({ x, y });
    };

    const handleMouseUp = () => {
      if (currentEraserPoints.length > 0) {
        const overlayW = overlayRef.current!.offsetWidth;
        const overlayH = overlayRef.current!.offsetHeight;
        const newId = `eraser-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        addEraser({
          id: newId,
          points: currentEraserPoints,
          strokeWidth: eraserSettings.brushSize,
          color: eraserSettings.color,
          page: currentPage,
          canvasWidth: overlayW,
          canvasHeight: overlayH,
        });
        setSelectedItem(newId, "eraser");
      }
      setIsEraserDrawing(false);
      setCurrentEraserPoints([]);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isEraserDrawing, currentEraserPoints, eraserSettings, currentPage, addEraser, setSelectedItem]);

  // Unified mouse down handler
  const handleItemMouseDown = useCallback(
    (e: React.MouseEvent, id: string, type: "stamp" | "text") => {
      e.stopPropagation();
      clickedOnElementRef.current = true;
      setSelectedItem(id, type);
      const state = usePdfEditorStore.getState();
      const item = type === "stamp" ? state.stamps.find(s => s.id === id) : state.texts.find(t => t.id === id);
      const cw = item ? ("canvasWidth" in item ? item.canvasWidth : canvasSize.width) : canvasSize.width;
      const ch = item ? ("canvasHeight" in item ? item.canvasHeight : canvasSize.height) : canvasSize.height;
      setDragState({
        mode: "move",
        id,
        type,
        offsetX: e.nativeEvent.offsetX,
        offsetY: e.nativeEvent.offsetY,
        startX: e.clientX,
        startY: e.clientY,
        startLeft: 0,
        startTop: 0,
        startWidth: 0,
        startHeight: 0,
        startRotation: 0,
        startAngle: 0,
        itemCanvasWidth: cw,
        itemCanvasHeight: ch,
      });
    },
    [setSelectedItem, canvasSize.width, canvasSize.height]
  );

  // Resize handle mouse down
  const handleResizeMouseDown = useCallback(
    (e: React.MouseEvent, id: string, corner: string, item: StampItem | TextItem) => {
      e.stopPropagation();
      e.preventDefault();
      clickedOnElementRef.current = true;
      const stampItem = item as StampItem;
      setDragState({
        mode: "resize",
        id,
        type: "stamp",
        corner,
        offsetX: 0,
        offsetY: 0,
        startX: e.clientX,
        startY: e.clientY,
        startLeft: stampItem.x,
        startTop: stampItem.y,
        startWidth: stampItem.width,
        startHeight: stampItem.height,
        startRotation: stampItem.rotation,
        startAngle: 0,
        itemCanvasWidth: stampItem.canvasWidth,
        itemCanvasHeight: stampItem.canvasHeight,
      });
    },
    []
  );

  // Rotation handle mouse down
  const handleRotateMouseDown = useCallback(
    (e: React.MouseEvent, id: string, item: StampItem) => {
      e.stopPropagation();
      e.preventDefault();
      clickedOnElementRef.current = true;
      // Calculate center of the element in DISPLAY coords
      const dispX = scaleToDisplay(item.x, item.canvasWidth);
      const dispY = scaleToDisplayY(item.y, item.canvasHeight);
      const dispW = scaleToDisplay(item.width, item.canvasWidth);
      const dispH = scaleToDisplayY(item.height, item.canvasHeight);
      const cx = dispX + dispW / 2;
      const cy = dispY + dispH / 2;
      const rect = overlayRef.current!.getBoundingClientRect();
      const mouseLocalX = e.clientX - rect.left;
      const mouseLocalY = e.clientY - rect.top;
      const angle = Math.atan2(mouseLocalY - cy, mouseLocalX - cx) * (180 / Math.PI);
      setDragState({
        mode: "rotate",
        id,
        type: "stamp",
        offsetX: 0,
        offsetY: 0,
        startX: e.clientX,
        startY: e.clientY,
        startLeft: item.x,
        startTop: item.y,
        startWidth: item.width,
        startHeight: item.height,
        startRotation: item.rotation,
        startAngle: angle,
        itemCanvasWidth: item.canvasWidth,
        itemCanvasHeight: item.canvasHeight,
      });
    },
    [scaleToDisplay, scaleToDisplayY]
  );

  // Unified mouse move / up handler
  useEffect(() => {
    if (!dragState || !overlayRef.current) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = overlayRef.current!.getBoundingClientRect();
      const icw = dragState.itemCanvasWidth;
      const ich = dragState.itemCanvasHeight;

      if (dragState.mode === "move") {
        // Display coords
        const dispX = e.clientX - rect.left - dragState.offsetX;
        const dispY = e.clientY - rect.top - dragState.offsetY;
        // Convert to store coords
        const storeX = dispX * (icw / (canvasSize.width || icw));
        const storeY = dispY * (ich / (canvasSize.height || ich));
        if (dragState.type === "stamp") updateStamp(dragState.id, { x: storeX, y: storeY });
        else updateText(dragState.id, { x: storeX, y: storeY });
      } else if (dragState.mode === "resize" && dragState.type === "stamp") {
        const dx = e.clientX - dragState.startX;
        const dy = e.clientY - dragState.startY;
        // Convert dx/dy from display pixels to store pixels
        const sdx = dx * (icw / (canvasSize.width || icw));
        const sdy = dy * (ich / (canvasSize.height || ich));

        let newLeft = dragState.startLeft;
        let newTop = dragState.startTop;
        let newWidth = dragState.startWidth;
        let newHeight = dragState.startHeight;

        const corner = dragState.corner;

        if (corner === "br") {
          newWidth = Math.max(30, dragState.startWidth + sdx);
          newHeight = Math.max(30, dragState.startHeight + sdy);
        } else if (corner === "bl") {
          newLeft = dragState.startLeft + sdx;
          newWidth = Math.max(30, dragState.startWidth - sdx);
          newHeight = Math.max(30, dragState.startHeight + sdy);
        } else if (corner === "tr") {
          newTop = dragState.startTop + sdy;
          newWidth = Math.max(30, dragState.startWidth + sdx);
          newHeight = Math.max(30, dragState.startHeight - sdy);
        } else if (corner === "tl") {
          newLeft = dragState.startLeft + sdx;
          newTop = dragState.startTop + sdy;
          newWidth = Math.max(30, dragState.startWidth - sdx);
          newHeight = Math.max(30, dragState.startHeight - sdy);
        }

        updateStamp(dragState.id, {
          x: newLeft,
          y: newTop,
          width: newWidth,
          height: newHeight,
        });
      } else if (dragState.mode === "rotate" && dragState.type === "stamp") {
        const stamp = usePdfEditorStore.getState().stamps.find(s => s.id === dragState.id);
        if (!stamp) return;
        // Use display coords for rotation calculation
        const dispX = scaleToDisplay(stamp.x, stamp.canvasWidth);
        const dispY = scaleToDisplayY(stamp.y, stamp.canvasHeight);
        const dispW = scaleToDisplay(stamp.width, stamp.canvasWidth);
        const dispH = scaleToDisplayY(stamp.height, stamp.canvasHeight);
        const cx = dispX + dispW / 2;
        const cy = dispY + dispH / 2;
        const mouseLocalX = e.clientX - rect.left;
        const mouseLocalY = e.clientY - rect.top;
        const currentAngle = Math.atan2(mouseLocalY - cy, mouseLocalX - cx) * (180 / Math.PI);
        const deltaAngle = currentAngle - dragState.startAngle;
        let newRotation = dragState.startRotation + deltaAngle;
        // Normalize to -180..180
        while (newRotation > 180) newRotation -= 360;
        while (newRotation < -180) newRotation += 360;
        // Snap to 15-degree increments when Shift is held
        if (e.shiftKey) {
          newRotation = Math.round(newRotation / 15) * 15;
        }
        updateStamp(dragState.id, { rotation: newRotation });
      }
    };

    const handleMouseUp = () => { setDragState(null); };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [dragState, updateStamp, updateText, canvasSize.width, canvasSize.height, scaleToDisplay, scaleToDisplayY]);

  // Text editing
  const handleTextDoubleClick = useCallback((e: React.MouseEvent, t: TextItem) => {
    e.stopPropagation();
    setEditingTextId(t.id);
    setEditTextValue(t.text);
  }, []);

  const handleTextEditComplete = useCallback(() => {
    if (editingTextId && editTextValue.trim()) updateText(editingTextId, { text: editTextValue.trim() });
    setEditingTextId(null);
    setEditTextValue("");
  }, [editingTextId, editTextValue, updateText]);

  const handleTextKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleTextEditComplete();
    else if (e.key === "Escape") { setEditingTextId(null); setEditTextValue(""); }
  }, [handleTextEditComplete]);

  // Keyboard delete
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (editingTextId) return;
      if ((e.key === "Delete" || e.key === "Backspace") && selectedItemId) {
        if (e.key === "Backspace" && !(e.target instanceof HTMLInputElement)) e.preventDefault();
        if (selectedItemType === "stamp") usePdfEditorStore.getState().removeStamp(selectedItemId);
        else if (selectedItemType === "text") usePdfEditorStore.getState().removeText(selectedItemId);
        else if (selectedItemType === "eraser") usePdfEditorStore.getState().removeEraser(selectedItemId);
        setSelectedItem(null, null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedItemId, selectedItemType, editingTextId, setSelectedItem]);

  // Keyboard arrow for pages
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (editingTextId || e.target instanceof HTMLInputElement) return;
      if (e.key === "ArrowLeft") setCurrentPage(Math.max(1, currentPage - 1));
      if (e.key === "ArrowRight") setCurrentPage(Math.min(totalPages, currentPage + 1));
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPage, totalPages, editingTextId, setCurrentPage]);

  const pageStamps = stamps.filter((s) => s.page === currentPage);
  const pageTexts = texts.filter((t) => t.page === currentPage);
  const pageErasers = erasers.filter((e) => e.page === currentPage);

  const cursorClass = activeTool === "stamp" && selectedStampSrc ? "cursor-none" : activeTool === "stamp" || activeTool === "text" ? "cursor-crosshair" : activeTool === "eraser" ? "cursor-none" : "cursor-default";
  const zoomPercent = Math.round(zoomLevel * 100);

  // Build SVG path string from eraser points
  const buildEraserPath = (points: EraserPoint[]): string => {
    if (points.length === 0) return "";
    if (points.length === 1) {
      // Single point — draw a circle (as a small path)
      const p = points[0];
      const r = 1;
      return `M ${p.x - r} ${p.y} A ${r} ${r} 0 1 0 ${p.x + r} ${p.y} A ${r} ${r} 0 1 0 ${p.x - r} ${p.y}`;
    }
    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      d += ` L ${points[i].x} ${points[i].y}`;
    }
    return d;
  };

  // Render resize handles for selected stamp
  const renderStampHandles = (stamp: StampItem) => {
    if (selectedItemId !== stamp.id) return null;

    const hs = HANDLE_SIZE;
    const halfHs = hs / 2;
    const corners = [
      { key: "tl", style: { left: -halfHs, top: -halfHs, cursor: "nw-resize" } },
      { key: "tr", style: { right: -halfHs, top: -halfHs, cursor: "ne-resize" } },
      { key: "bl", style: { left: -halfHs, bottom: -halfHs, cursor: "sw-resize" } },
      { key: "br", style: { right: -halfHs, bottom: -halfHs, cursor: "se-resize" } },
    ];

    return (
      <>
        {/* Dashed border */}
        <div className="absolute inset-0 border-2 border-dashed border-primary/60 pointer-events-none" />

        {/* Corner resize handles */}
        {corners.map((c) => (
          <div
            key={c.key}
            className="absolute bg-white border-2 border-primary rounded-sm z-10"
            style={{
              ...c.style,
              width: hs,
              height: hs,
              cursor: c.cursor,
            }}
            onMouseDown={(e) => handleResizeMouseDown(e, stamp.id, c.key, stamp)}
          />
        ))}

        {/* Rotation handle */}
        <div
          className="absolute left-1/2 z-10"
          style={{
            top: -ROTATE_HANDLE_DISTANCE,
            transform: "translateX(-50%)",
            cursor: "grab",
          }}
          onMouseDown={(e) => handleRotateMouseDown(e, stamp.id, stamp)}
        >
          {/* Connecting line */}
          <div
            className="absolute left-1/2 bottom-full"
            style={{
              width: 1,
              height: ROTATE_HANDLE_DISTANCE - hs,
              backgroundColor: "hsl(var(--primary))",
              transform: "translateX(-50%)",
              pointerEvents: "none",
            }}
          />
          {/* Rotation circle */}
          <div
            className="w-5 h-5 rounded-full bg-primary border-2 border-white shadow-md flex items-center justify-center"
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2" />
            </svg>
          </div>
        </div>
      </>
    );
  };

  const selectedStamp = stamps.find((s) => s.id === selectedItemId);
  const selectedText = texts.find((t) => t.id === selectedItemId);

  // Determine if we should show the top bar
  const showTopBar = pdfDoc && !error && !isLoading && (
    (activeTool === "text" && !selectedItemId) ||
    (activeTool === "eraser") ||
    (selectedItemId !== null)
  );

  return (
    <div ref={containerRef} className="flex-1 flex flex-col overflow-hidden bg-muted/30 relative">
      {/* Canvas area */}
      <div className="flex-1 flex items-center justify-center p-5 overflow-auto">
        {error && (
          <div className="text-center p-8">
            <div className="text-destructive text-lg mb-2">⚠️ {error}</div>
            <p className="text-muted-foreground text-sm">Попробуйте загрузить другой файл</p>
          </div>
        )}

        {isLoading && !error && (
          <div className="flex flex-col items-center justify-center gap-3">
            <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full" />
            <span className="text-sm text-muted-foreground">Загрузка PDF...</span>
          </div>
        )}

        {pdfDoc && !error && !isLoading && (
          <div className="relative shadow-2xl border border-border rounded-lg overflow-hidden">
            <canvas ref={canvasRef} className="block" />

            {/* Overlay */}
            <div
              ref={overlayRef}
              className={`absolute top-0 left-0 ${cursorClass}`}
              onClick={handleOverlayClick}
              onMouseDown={handleOverlayMouseDown}
              onMouseMove={(e) => {
                const rect = overlayRef.current!.getBoundingClientRect();
                const pos = { x: e.clientX - rect.left, y: e.clientY - rect.top };
                if (activeTool === "eraser") setEraserCursorPos(pos);
                if (activeTool === "stamp" && selectedStampSrc) setStampCursorPos(pos);
              }}
              onMouseLeave={() => { setEraserCursorPos(null); setStampCursorPos(null); }}
              style={{ width: canvasSize.width, height: canvasSize.height }}
            >
              {/* SVG layer for eraser strokes */}
              <svg
                className="absolute top-0 left-0 pointer-events-none"
                width={canvasSize.width}
                height={canvasSize.height}
                style={{ zIndex: 5 }}
              >
                {pageErasers.map((eraserItem) => {
                  const sx = canvasSize.width / (eraserItem.canvasWidth || canvasSize.width);
                  const sy = canvasSize.height / (eraserItem.canvasHeight || canvasSize.height);
                  const scaledPoints = eraserItem.points.map(p => ({ x: p.x * sx, y: p.y * sy }));
                  return (
                  <path
                    key={eraserItem.id}
                    d={buildEraserPath(scaledPoints)}
                    stroke={eraserItem.color}
                    strokeWidth={eraserItem.strokeWidth * Math.min(sx, sy)}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                    className={selectedItemId === eraserItem.id ? "pointer-events-auto cursor-pointer" : "pointer-events-none"}
                    onClick={(e) => {
                      if (activeTool === "select" || activeTool === "eraser") {
                        e.stopPropagation();
                        clickedOnElementRef.current = true;
                        setSelectedItem(eraserItem.id, "eraser");
                      }
                    }}
                  />
                  );
                })}
                {/* Current drawing stroke */}
                {isEraserDrawing && currentEraserPoints.length > 0 && (
                  <path
                    d={buildEraserPath(currentEraserPoints)}
                    stroke={eraserSettings.color}
                    strokeWidth={eraserSettings.brushSize}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                  />
                )}
              </svg>

              {pageStamps.map((stamp) => (
                <div
                  key={stamp.id}
                  className={`absolute ${selectedItemId === stamp.id ? "" : "hover:ring-1 hover:ring-primary/50"}`}
                  style={{
                    left: scaleToDisplay(stamp.x, stamp.canvasWidth),
                    top: scaleToDisplayY(stamp.y, stamp.canvasHeight),
                    width: scaleToDisplay(stamp.width, stamp.canvasWidth),
                    height: scaleToDisplayY(stamp.height, stamp.canvasHeight),
                    transform: `rotate(${stamp.rotation}deg)`,
                    opacity: stamp.opacity,
                    cursor: dragState?.mode === "move" ? "grabbing" : "grab",
                  }}
                  onMouseDown={(e) => handleItemMouseDown(e, stamp.id, "stamp")}
                  onClick={(e) => e.stopPropagation()}
                >
                  <img
                    src={stamp.src}
                    alt={stamp.type}
                    className="w-full h-full object-contain pointer-events-none select-none"
                    draggable={false}
                  />
                  {renderStampHandles(stamp)}
                </div>
              ))}

              {pageTexts.map((textItem) => {
                const dispX = scaleToDisplay(textItem.x, textItem.canvasWidth);
                const dispY = scaleToDisplayY(textItem.y, textItem.canvasHeight);
                const dispFontSize = scaleToDisplay(textItem.fontSize, textItem.canvasWidth);
                return (
                <div
                  key={textItem.id}
                  className={`absolute ${selectedItemId === textItem.id && editingTextId !== textItem.id ? "ring-1 ring-primary/70 p-0.5" : editingTextId !== textItem.id ? "hover:ring-1 hover:ring-primary/50" : ""}`}
                  style={{
                    left: dispX,
                    top: dispY,
                    color: textItem.color,
                    transform: `rotate(${textItem.rotation}deg)`,
                    cursor: editingTextId === textItem.id ? "text" : dragState?.mode === "move" ? "grabbing" : "grab",
                    userSelect: "none",
                    whiteSpace: "nowrap",
                    lineHeight: 1.2,
                    width: "fit-content",
                  }}
                  onMouseDown={(e) => handleItemMouseDown(e, textItem.id, "text")}
                  onClick={(e) => e.stopPropagation()}
                  onDoubleClick={(e) => handleTextDoubleClick(e, textItem)}
                >
                  {editingTextId === textItem.id ? (
                    <input
                      type="text"
                      value={editTextValue}
                      onChange={(e) => setEditTextValue(e.target.value)}
                      onBlur={handleTextEditComplete}
                      onKeyDown={handleTextKeyDown}
                      className="bg-white/90 border border-primary/40 px-1 outline-none"
                      style={{
                        fontSize: dispFontSize,
                        color: textItem.color,
                        fontFamily: getFontCss(textItem.fontFamily),
                        fontWeight: textItem.bold ? "bold" : "normal",
                        fontStyle: textItem.italic ? "italic" : "normal",
                      }}
                      autoFocus
                    />
                  ) : (
                    <span
                      style={{
                        fontSize: dispFontSize,
                        fontFamily: getFontCss(textItem.fontFamily),
                        fontWeight: textItem.bold ? "bold" : "normal",
                        fontStyle: textItem.italic ? "italic" : "normal",
                      }}
                    >{textItem.text}</span>
                  )}
                </div>
                );
              })}

              {/* Stamp cursor preview — stamp image follows mouse */}
              {activeTool === "stamp" && selectedStampSrc && stampCursorPos && (
                <img
                  src={selectedStampSrc}
                  alt=""
                  className="absolute pointer-events-none object-contain"
                  style={{
                    width: 130,
                    height: 130,
                    left: stampCursorPos.x,
                    top: stampCursorPos.y,
                    transform: "translate(-50%, -50%)",
                    opacity: 0.7,
                    zIndex: 50,
                  }}
                  draggable={false}
                />
              )}

              {/* Eraser cursor preview — circle that follows mouse */}
              {activeTool === "eraser" && eraserCursorPos && (
                <div
                  className="absolute pointer-events-none rounded-full border-2 border-gray-500"
                  style={{
                    width: eraserSettings.brushSize,
                    height: eraserSettings.brushSize,
                    left: eraserCursorPos.x,
                    top: eraserCursorPos.y,
                    transform: "translate(-50%, -50%)",
                    backgroundColor: eraserSettings.color,
                    opacity: 0.6,
                    zIndex: 50,
                  }}
                />
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating properties bar — absolute positioned, doesn't shift PDF */}
      {showTopBar && (
        <div className="absolute top-0 left-0 right-0 z-20 flex items-center gap-3 px-4 py-2 bg-card/95 backdrop-blur-sm border-b border-border overflow-x-auto">
          {/* Text tool settings (shown when text tool is active and no element selected) */}
          {activeTool === "text" && !selectedItemId && (
            <>
              {/* Font selector */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Шрифт</span>
                <select
                  value={textSettings.fontFamily}
                  onChange={(e) => setTextSettings({ fontFamily: e.target.value })}
                  className="h-7 rounded border border-input bg-background px-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  {AVAILABLE_FONTS.map((font) => (
                    <option key={font.id} value={font.id}>{font.name}</option>
                  ))}
                </select>
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Font size */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Размер</span>
                <Input
                  type="number" min={6} max={96}
                  value={textSettings.fontSize}
                  onChange={(e) => setTextSettings({ fontSize: parseInt(e.target.value) || 14 })}
                  className="h-7 text-sm w-14 text-center"
                />
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Bold */}
              <Button
                variant={textSettings.bold ? "default" : "outline"}
                size="icon" className="h-7 w-7 shrink-0"
                onClick={() => setTextSettings({ bold: !textSettings.bold })}
                title="Жирный"
              >
                <Bold className="h-3 w-3" />
              </Button>

              {/* Italic */}
              <Button
                variant={textSettings.italic ? "default" : "outline"}
                size="icon" className="h-7 w-7 shrink-0"
                onClick={() => setTextSettings({ italic: !textSettings.italic })}
                title="Курсив"
              >
                <Italic className="h-3 w-3" />
              </Button>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Color */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Цвет</span>
                <Input
                  type="color"
                  value={textSettings.color}
                  onChange={(e) => setTextSettings({ color: e.target.value })}
                  className="h-7 w-8 cursor-pointer p-0"
                />
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {presetText ? (
                <span className="text-xs text-primary font-medium shrink-0 truncate max-w-60">✦ {presetText}</span>
              ) : (
                <span className="text-xs text-muted-foreground shrink-0">Кликните на PDF чтобы добавить текст</span>
              )}
            </>
          )}

          {/* Eraser tool settings */}
          {activeTool === "eraser" && (
            <>
              <Eraser className="h-4 w-4 shrink-0 text-muted-foreground" />
              
              {/* Brush size presets */}
              <div className="flex items-center gap-1 shrink-0">
                {[5, 10, 20, 40, 60].map((size) => (
                  <Button
                    key={size}
                    variant={eraserSettings.brushSize === size ? "default" : "outline"}
                    size="sm"
                    className="h-7 px-2 text-xs shrink-0"
                    onClick={() => setEraserSettings({ brushSize: size })}
                  >
                    {size}
                  </Button>
                ))}
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Color */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Цвет</span>
                <Input
                  type="color"
                  value={eraserSettings.color}
                  onChange={(e) => setEraserSettings({ color: e.target.value })}
                  className="h-7 w-8 cursor-pointer p-0"
                />
              </div>

              {/* Quick colors */}
              <div className="flex items-center gap-1 shrink-0">
                {["#FFFFFF", "#000000", "#F5F5F5", "#D4D4D4"].map((c) => (
                  <button
                    key={c}
                    className={`w-5 h-5 rounded border-2 ${eraserSettings.color === c ? "border-primary" : "border-border"} transition-colors shrink-0`}
                    style={{ backgroundColor: c }}
                    onClick={() => setEraserSettings({ color: c })}
                    title={c}
                  />
                ))}
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Delete selected eraser */}
              {selectedItemId && selectedItemType === "eraser" && (
                <Button
                  variant="destructive" size="sm"
                  className="h-7 gap-1.5 shrink-0"
                  onClick={() => {
                    usePdfEditorStore.getState().removeEraser(selectedItemId);
                    setSelectedItem(null, null);
                  }}
                >
                  <Trash2 className="h-3 w-3" />
                  Удалить
                </Button>
              )}

              <span className="text-xs text-muted-foreground shrink-0">Рисуйте на PDF чтобы замазать</span>
            </>
          )}

          {/* Stamp selected element properties */}
          {selectedItemId && selectedItemType === "stamp" && selectedStamp && (
            <>
              {/* Rotation */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Поворот</span>
                <Button variant="outline" size="icon" className="h-7 w-7"
                  onClick={() => updateStamp(selectedItemId!, { rotation: selectedStamp.rotation - 15 })}
                >
                  <RotateCcw className="h-3 w-3" />
                </Button>
                <Input
                  type="number" min={-180} max={180} step={1}
                  value={Math.round(selectedStamp.rotation)}
                  onChange={(e) => updateStamp(selectedItemId!, { rotation: parseFloat(e.target.value) || 0 })}
                  className="h-7 text-sm w-14 text-center"
                />
                <span className="text-xs text-muted-foreground">°</span>
                <Button variant="outline" size="icon" className="h-7 w-7"
                  onClick={() => updateStamp(selectedItemId!, { rotation: selectedStamp.rotation + 15 })}
                >
                  <RotateCw className="h-3 w-3" />
                </Button>
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Width */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Ш</span>
                <Input
                  type="number" min={20} max={800} step={5}
                  value={Math.round(selectedStamp.width)}
                  onChange={(e) => updateStamp(selectedItemId!, { width: Math.max(20, parseInt(e.target.value) || 20) })}
                  className="h-7 text-sm w-16 text-center"
                />
              </div>

              {/* Height */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">В</span>
                <Input
                  type="number" min={20} max={800} step={5}
                  value={Math.round(selectedStamp.height)}
                  onChange={(e) => updateStamp(selectedItemId!, { height: Math.max(20, parseInt(e.target.value) || 20) })}
                  className="h-7 text-sm w-16 text-center"
                />
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Opacity */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Прозрачность</span>
                <Input
                  type="range" min={0.05} max={1} step={0.05}
                  value={selectedStamp.opacity}
                  onChange={(e) => updateStamp(selectedItemId!, { opacity: parseFloat(e.target.value) })}
                  className="w-20 h-7"
                />
                <span className="text-xs text-muted-foreground w-8 text-right">
                  {Math.round(selectedStamp.opacity * 100)}%
                </span>
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Delete */}
              <Button
                variant="destructive" size="sm"
                className="h-7 gap-1.5 shrink-0"
                onClick={() => {
                  usePdfEditorStore.getState().removeStamp(selectedItemId!);
                  setSelectedItem(null, null);
                }}
              >
                <Trash2 className="h-3 w-3" />
                Удалить
              </Button>
            </>
          )}

          {/* Text selected element properties */}
          {selectedItemId && selectedItemType === "text" && selectedText && (
            <>
              {/* Font selector */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Шрифт</span>
                <select
                  value={selectedText.fontFamily}
                  onChange={(e) => updateText(selectedItemId!, { fontFamily: e.target.value })}
                  className="h-7 rounded border border-input bg-background px-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  {AVAILABLE_FONTS.map((font) => (
                    <option key={font.id} value={font.id}>{font.name}</option>
                  ))}
                </select>
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Font size */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Размер</span>
                <Input
                  type="number" min={6} max={96}
                  value={selectedText.fontSize}
                  onChange={(e) => updateText(selectedItemId!, { fontSize: parseInt(e.target.value) || 14 })}
                  className="h-7 text-sm w-14 text-center"
                />
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Bold */}
              <Button
                variant={selectedText.bold ? "default" : "outline"}
                size="icon" className="h-7 w-7 shrink-0"
                onClick={() => updateText(selectedItemId!, { bold: !selectedText.bold })}
                title="Жирный"
              >
                <Bold className="h-3 w-3" />
              </Button>

              {/* Italic */}
              <Button
                variant={selectedText.italic ? "default" : "outline"}
                size="icon" className="h-7 w-7 shrink-0"
                onClick={() => updateText(selectedItemId!, { italic: !selectedText.italic })}
                title="Курсив"
              >
                <Italic className="h-3 w-3" />
              </Button>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Color */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Цвет</span>
                <Input
                  type="color"
                  value={selectedText.color}
                  onChange={(e) => updateText(selectedItemId!, { color: e.target.value })}
                  className="h-7 w-8 cursor-pointer p-0"
                />
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Rotation */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-muted-foreground">Поворот</span>
                <Button variant="outline" size="icon" className="h-7 w-7"
                  onClick={() => updateText(selectedItemId!, { rotation: selectedText.rotation - 15 })}
                >
                  <RotateCcw className="h-3 w-3" />
                </Button>
                <Input
                  type="number" min={-180} max={180} step={1}
                  value={Math.round(selectedText.rotation)}
                  onChange={(e) => updateText(selectedItemId!, { rotation: parseFloat(e.target.value) || 0 })}
                  className="h-7 text-sm w-14 text-center"
                />
                <span className="text-xs text-muted-foreground">°</span>
                <Button variant="outline" size="icon" className="h-7 w-7"
                  onClick={() => updateText(selectedItemId!, { rotation: selectedText.rotation + 15 })}
                >
                  <RotateCw className="h-3 w-3" />
                </Button>
              </div>

              <div className="w-px h-6 bg-border shrink-0" />

              {/* Delete */}
              <Button
                variant="destructive" size="sm"
                className="h-7 gap-1.5 shrink-0"
                onClick={() => {
                  usePdfEditorStore.getState().removeText(selectedItemId!);
                  setSelectedItem(null, null);
                }}
              >
                <Trash2 className="h-3 w-3" />
                Удалить
              </Button>
            </>
          )}

          {/* Eraser selected element properties (when in select mode) */}
          {selectedItemId && selectedItemType === "eraser" && activeTool === "select" && (
            <Button
              variant="destructive" size="sm"
              className="h-7 gap-1.5 shrink-0"
              onClick={() => {
                usePdfEditorStore.getState().removeEraser(selectedItemId);
                setSelectedItem(null, null);
              }}
            >
              <Trash2 className="h-3 w-3" />
              Удалить мазок
            </Button>
          )}
        </div>
      )}

      {/* Bottom center controls */}
      {pdfDoc && !error && !isLoading && (
        <div className="flex justify-center pb-3 px-4">
          <div className="flex items-center gap-1 bg-card border border-border rounded-full shadow-lg px-2 py-1">
            <Button
              variant="ghost" size="icon" className="h-8 w-8 rounded-full"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage <= 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium tabular-nums min-w-[60px] text-center select-none">
              {currentPage} / {totalPages}
            </span>
            <Button
              variant="ghost" size="icon" className="h-8 w-8 rounded-full"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage >= totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            <div className="w-px h-5 bg-border mx-1" />
            <Button
              variant="ghost" size="icon" className="h-8 w-8 rounded-full"
              onClick={zoomOut}
              disabled={zoomLevel <= 0.25}
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <button
              className="text-sm font-medium tabular-nums min-w-[48px] text-center hover:bg-accent rounded-full py-1 px-2 transition-colors select-none"
              onClick={zoomFit}
              title="Сбросить масштаб"
            >
              {zoomPercent}%
            </button>
            <Button
              variant="ghost" size="icon" className="h-8 w-8 rounded-full"
              onClick={zoomIn}
              disabled={zoomLevel >= 3.0}
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost" size="icon" className="h-8 w-8 rounded-full"
              onClick={zoomFit}
              title="Вписать в экран"
            >
              <Maximize className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
